/**
 * Main entry point for Campus Course & Records Manager (CCRM)
 * Demonstrates Java SE application structure
 */
public class Main {
    public static void main(String[] args) {
        edu.ccrm.cli.CCRMApplication app = new edu.ccrm.cli.CCRMApplication();
        app.run();
    }
}



